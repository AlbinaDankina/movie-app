import { format } from 'date-fns';
import { Rate } from 'antd';
import { useEffect, useContext } from 'react';

import './items-list.css';
import Spinner from '../spinner';
import { truncateName, truncate } from '../../logics/truncate-text';
import { onPostRate, getToken, findMatchedGenres } from '../service/fetch-data';
import { MovieContext } from '../service/movie-context';


const ItemsList = ({ items }) => {

  const { genres } = useContext(MovieContext);
 
  // запись guest_session_id в localStorage, чтобы к одному и тому же ID добавлять в дальнейшем фильмы с рейтингом 
  // >> для вызова этих к/ф на вкладке Search 
  // ??? делаем пустой массив зависимостей, чтобы токен создался разово - ???
  useEffect( ()=>{
    const availableToken = localStorage.getItem('guest_session_id');
    
    if (!availableToken) {
      getToken()
      .then((res) =>{ 
        console.log( res.guest_session_id);
        let guestSessionId = res.guest_session_id;
        return guestSessionId
      })
      .then(res => localStorage.setItem('guest_session_id', res))
      .catch((err) => console.error(err));
    }
  }, []);

  // формируем карточки фильмов
  const movieCards = items.map((item) => {

    // для каждого фильма вытягиваем массив с id его жанров:
    let itemGenresIdx = item.genre_ids;
    
    // В fetch-data завели функцию, возвращающую массив НАИМЕНОВАНИЙ совпавших жанров по КАЖДОМУ фильму:
    const itemGenres = findMatchedGenres(itemGenresIdx, genres);
    let genreNames = [];
    const itemGenresNames = itemGenres.map((genre) => genreNames.push(genre.name));
    
    return (
      <li key={item.id} className="item">

        <div className="img-container" style={{width: "183px", height: "281px"}}>
          <img src={`https://image.tmdb.org/t/p/original${item.poster_path}`} alt="no poster available" />
        </div>
        
        <div className="item_info">

          <h1>{truncateName(item.title)}</h1>
          {item.release_date ? <h3>{format(new Date(item.release_date), 'MMM dd, yyyy')}</h3> : null}
          
          <span>{genreNames.join(', ')}</span>
          
          <p className="description">{truncate(item.overview)}</p>

          <div className="item_ranking" style={{
                    border:
                    item.vote_average <= 3
                        ? "2px solid #E90000"
                        : 3 < item.vote_average && item.vote_average <= 5
                        ? "#2px solid E97E00"
                        : 5 < item.vote_average && item.vote_average <= 7
                        ? "2px solid #E9D100"
                        : "2px solid #66E900",
                  }}>{item.vote_average}</div>
          
          <div  style={{ display: 'block', position:'absolute', bottom:'10px'}}>
            <Rate onChange={(value) => onPostRate(item.id, value)} count={10} />
          </div>
          
        </div>
    </li>
    )
  });

  if (!movieCards) <Spinner />;

  return ( 
        <div className="container">
          <ul className="items_list" >
            {movieCards}
          </ul>
        </div>
    );
  };

export default ItemsList;
