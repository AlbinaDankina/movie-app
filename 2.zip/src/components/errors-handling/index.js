import ErrorBoundary from '../../../../error-boundary.jsx';

export default ErrorBoundary;
