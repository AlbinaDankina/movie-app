
import { Pagination, Tabs } from 'antd';
import { useEffect, useState } from 'react';
import { debounce } from 'lodash';
import "antd/dist/antd.css";
import './app2.css';

import InternetConnectionDetector from '../errors-handling/internet-connection-detector.jsx';
import Input from '../input/input';
import ItemsList from '../items-list/items-list';
import RatedList from '../rated-list/rated-list';
import Spinner from '../spinner';
import ErrorIndicator from '../errors-handling/error-indicator';
import { getRatedMovies, getData, getGenres } from '../service/fetch-data';
import { MovieContext } from '../service/movie-context';

const App = () => {

  const [error, setError] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const [items, setItems] = useState([]); // все найденное
  const [input, setInput] = useState('');  // данные из input
  const [current, setCurrent] = useState(1); // текущ страница
  const [totalPages, setTotalPages] = useState(1);
  const [ratedFilm, setRatedFilm] = useState([]); // фильмы, которым проставили рейтинги
  const [genres, setGenres] = useState([]); // список жанров

  // начальный вызов фильмов на странцие Search с query = 'return':
  useEffect(() => {
    getData('return', current, setIsLoaded, setItems, setError, setTotalPages, setInput);
  }, []);

  // вызов фильмов с задержкой по набору в input:
  const searchMovie = debounce((text, page) => {
    if (text !== '') {
      getData(text, page, setIsLoaded, setItems, setError, setTotalPages, setInput); 
    };
  }, 1000);

  // пагинация на Search
  const pagination = (page) => {
    setCurrent(page);
    getData(input, page, setIsLoaded, setItems, setError, setTotalPages, setInput);
  };

  // вызов фильмов с рейтингом для вкладки Rated:
  useEffect(()=>{
    getRatedMovies(setRatedFilm);
  }, []);

  // вызов жанров и запись в контекст и стейт? 
  useEffect(() => {
    getGenres(setGenres)
  }, []);
 
  if (error) return <ErrorIndicator />;
  if (!items && !isLoaded) return <Spinner />;

  return (
    <>
      <InternetConnectionDetector />
      < MovieContext.Provider 
        value={genres}
      >
      <Tabs centered style={{backgroundColor:'white'}}
        defaultActiveKey="1"
        onChange={(e) => {
          if (e === "2") {
            getRatedMovies(setRatedFilm);
          }
        }} 
        items={[
          {
            label: `Search`,
            key: '1',
            children: [
              < MovieContext.Provider value={{genres}} >
                <Input 
                  searchMovie={searchMovie} 
                    setInput={setInput} 
                  input={input}
                  />, 
                {items.length !== 0 ?  
                <ItemsList
                  items={items} 
                  isLoaded={isLoaded} 
                  input={input} /> : <Spinner />},
                <Pagination 
                    defaultCurrent={1} 
                size="small"
                pageSize={20}
                showQuickJumper={false}
                showLessItems={false}
                onChange={pagination}
                total={totalPages} 
                style={{marginLeft: "auto", marginRight:"auto", width:"300px" }}  
                className="ant-pagination pagination" />
              </MovieContext.Provider>]
          },
          {
            label: `Rated`,
            key: '2',
            children: [ 
            <RatedList ratedFilm={ratedFilm}/>
            ],
          }
        ]}
      />
      </MovieContext.Provider>
    </>
 )
};

export default App;
