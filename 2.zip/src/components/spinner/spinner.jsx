import './spinner.css';

const Spinner = () => (
  <div className="loadingio-spinner-eclipse-4lq3xlpgc3e">
    <div className="ldio-wb9j5tne9n">
      <div />
    </div>
  </div>
);

export default Spinner;
