import { Rate } from 'antd';
import { format } from 'date-fns';

import { truncate } from '../../logics/truncate-text';
import '../rated-list/item2.css';
// import { MovieContext } from '../service/movie-context';


const RatedList = ({ratedFilm}) => {
    return(
      <div className="container">
        <ul className="items_list">
        {ratedFilm.map((item) => (
          <li key={item.id} className="item">
            <div className="img-container" style={{width: "183px", height: "281px"}}>
              <img src={`https://image.tmdb.org/t/p/original${item.poster_path}`} alt="some pic" />
            </div>
            <div className="item_info item_info-relative">
              <h1>{truncate(item.title)}</h1>
              {item.release_date ? <h3>{format(new Date(item.release_date), 'MMM dd, yyyy')}</h3> : null}
              <span>Тут будет жанр</span>
              <p className="description">{truncate(item.overview)}</p>
              <div className="item_ranking" style={{
                  border:
                  item.vote_average <= 3
                      ? "2px solid #E90000"
                      : 3 < item.vote_average && item.vote_average <= 5
                      ? "#2px solid E97E00"
                      : 5 < item.vote_average && item.vote_average <= 7
                      ? "2px solid #E9D100"
                      : "2px solid #66E900",
                }}>{(item.vote_average).toFixed(1)}</div>
              <span>
                <div  style={{ display: 'block', position: 'absolute', bottom:'10px' }}>
                <Rate  
                count={10}
                />
                </div>
              </span>
            </div>
          </li>
        ))}
        </ul>
      </div>
    );
};

export default RatedList;