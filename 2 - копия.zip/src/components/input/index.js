import Input from './input.jsx';

export default Input;
