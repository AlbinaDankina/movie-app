import ItemsList from './items-list.jsx';

export default ItemsList;
