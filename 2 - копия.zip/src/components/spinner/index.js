// eslint-disable-next-line import/extensions
import Spinner from './spinner.jsx';

export default Spinner;
